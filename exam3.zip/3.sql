--3. 부서번호(DNO)가 10 또는 30 에 속하고, 
--부서번호별, 부서명별 최고급여가 3000 이상인 사원의 
--부서번호, 부서명, 최고급여를 화면에 표시하세요

SELECT D.DNO AS 부서번호 ,D.DNAME AS 부서명 , SALARY AS 최고급여
FROM EMPLOYEE E,DEPARTMENT D
WHERE E.DNO=D.DNO
AND SALARY IN(SELECT MAX(SALARY)
                                    FROM EMPLOYEE
                                    WHERE SALARY >= 3000
                                    AND DNO IN(10,30)
                                    GROUP BY DNO );
                                    
                                    
                                



