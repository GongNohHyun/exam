/**
 * 
 */
package egovframework.example.exam4;

/**
 * @author user
 *
 */
public class a {
// 1. 스프링 MVC 디자인 패턴에 대해서 설명해주세요
	
//	   MVC 디자인 패턴
//    MODEL       : 모델(폴더) : 데이터 저장 코딩 (DB)
//    VIEW        : 화면에 관련된 코딩 (JSP) / HTML,CSS,JS,JQUERY ...
//    CONTROLLER  : 화면과 URL을 연결하는 코딩법,MODEL에서 전달받은 데이터를 보내줌.
//	
}
