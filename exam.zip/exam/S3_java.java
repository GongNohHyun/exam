/**
 * 
 */
package exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 * @author user
 * 3번 문제
 */
public class S3_java {
	public static void main(String[] args) {
			Scanner a=new Scanner(System.in);
			int N= a.nextInt();
			
			for (int i = 1; i <= 5; i++) {
				if (i == 2) {
					continue;
				}
				System.out.println(i);
	}
//			Arrays
	}
}
